CREATE TRIGGER insertLoc
BEFORE INSERT ON locataire
FOR EACH ROW
  begin
Declare nbL int;
select count(*) into nbL from Tiers where idtiers = new.idtiers;
if nbL = 0 then
insert into tiers values (new.idtiers);
end if;
end;
