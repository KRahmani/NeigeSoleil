CREATE TRIGGER insertProp
BEFORE INSERT ON proprietaire
FOR EACH ROW
  begin
Declare nbP int;
select count(*) into nbP from Tiers where idtiers = new.idtiers;
if nbP = 0 then
insert into tiers values (new.idtiers);
end if;
end;
